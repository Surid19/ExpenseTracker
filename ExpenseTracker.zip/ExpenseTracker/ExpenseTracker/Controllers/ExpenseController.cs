﻿using BLL.Services;
using BLL.DTOs;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace ExpenseTracker.Controllers 
{
   
    public class ExpenseController : ApiController
    {

        [HttpGet]
        [Route("api/expenses")]
        public HttpResponseMessage GetAll()
        {
            try
            {
                var data = ExpenseService.Get();
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

        [HttpGet]
        [Route("api/expenses/{id}")]
        public HttpResponseMessage Get(int id)
        {
            try
            {
                var data = ExpenseService.Get(id);
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

       
        [HttpPost]
        [Route("api/expenses")]
        public HttpResponseMessage Create([FromBody] ExpenseDTO expenseDto)
        {
            try
            {
                var createdExpense = ExpenseService.Create(expenseDto);
                return Request.CreateResponse(HttpStatusCode.Created, createdExpense);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

        [HttpPut]
        [Route("api/expenses")]
        public HttpResponseMessage Update([FromBody] ExpenseDTO expenseDto)
        {
            try
            {
                var updatedExpense = ExpenseService.Update(expenseDto);
                return Request.CreateResponse(HttpStatusCode.OK, updatedExpense);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

        [HttpDelete]
        [Route("api/expenses/{id}")]
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                var isDeleted = ExpenseService.Delete(id);
                return Request.CreateResponse(HttpStatusCode.OK, isDeleted);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

        [HttpGet]
        [Route("api/expenses/category/{category}")]
        public HttpResponseMessage GetByCategory(string category)
        {
            try
            {
                var data = ExpenseService.GetByCategory(category);
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

        [HttpGet]
        [Route("api/expenses/date/{date}")]
        public HttpResponseMessage GetByDate(string date)
        {
            if (!DateTime.TryParse(date, out DateTime parsedDate))
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, new { Message = "Invalid date format." });
            }

            try
            {
                var data = ExpenseService.GetByDate(parsedDate);
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

        [HttpGet]
        [Route("api/expenses/recurring")]
        public HttpResponseMessage GetRecurring()
        {
            try
            {
                var data = ExpenseService.GetRecurring();
                return Request.CreateResponse(HttpStatusCode.OK, data);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }



        [HttpGet]
        [Route("api/expenses/export/csv")]
        public HttpResponseMessage ExportToCSV()
        {
            try
            {
                var csvData = ExpenseService.ExportToCSV();

                var result = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(csvData)
                };

                result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                {
                    FileName = "Expenses.csv"
                };
                result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("text/csv");

                return result;
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.InternalServerError, new { Message = ex.Message });
            }
        }

    }
}
