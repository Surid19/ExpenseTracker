﻿using System.Web.Http;
using BLL.DTOs;
using BLL.Services;
using System.Collections.Generic;

namespace ExpenseTracker.Controllers
{
    [RoutePrefix("api/users")]
    public class UserController : ApiController
    {
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAllUsers()
        {
            var users = UserService.Get();
            return Ok(users);
        }

        [HttpGet]
        [Route("{username}")]
        public IHttpActionResult GetUser(string username)
        {
            var user = UserService.Get(username);
            if (user == null)
                return NotFound();

            return Ok(user);
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult CreateUser([FromBody] UserDTO userDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdUser = UserService.Create(userDto);
            return Created($"api/users/{createdUser.Uname}", createdUser);
        }

        [HttpPut]
        [Route("{username}")]
        public IHttpActionResult UpdateUser(string username, [FromBody] UserDTO userDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (userDto.Uname != username)
                return BadRequest("Usernames do not match.");

            var updatedUser = UserService.Update(userDto);
            if (updatedUser == null)
                return NotFound();

            return Ok(updatedUser);
        }

        [HttpDelete]
        [Route("{username}")]
        public IHttpActionResult DeleteUser(string username)
        {
            var deleted = UserService.Delete(username);
            if (!deleted)
                return NotFound();

            return StatusCode(System.Net.HttpStatusCode.NoContent);
        }
    }
}
