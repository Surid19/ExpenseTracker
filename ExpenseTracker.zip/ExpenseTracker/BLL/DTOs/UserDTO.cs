﻿using System;

namespace BLL.DTOs
{
    public class UserDTO
    {
        public string Uname { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
    }
}
